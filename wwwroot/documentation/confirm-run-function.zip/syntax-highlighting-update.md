# Enhanced Syntax Highlighting Implementation

The previous implementation had some issues with how code blocks were being handled. Let me improve it to:

1. Better detect code blocks in different message types
2. Apply appropriate language classes based on context
3. Handle edge cases properly
4. Make the highlighting more robust

## Improvements:
- Detect when content contains code blocks and apply proper highlighting
- Use Prism.js autoloader for automatic language detection
- Improve the handling of different message types
- Add better error handling